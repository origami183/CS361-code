#ifndef __cs361_shell__
#define __cs361_shell__

void shell (FILE *);

#endif
