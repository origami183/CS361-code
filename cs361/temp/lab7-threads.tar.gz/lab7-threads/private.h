#ifndef __private_h__
#define __private_h__

void * generator (void *);

#endif
