#ifndef __CS361_PINGPONG__
#define __CS361_PINGPONG__

int ping (void);

#endif
