#ifndef __CS361_FPTR__
#define __CS361_FPTR__

#include <stdbool.h>

int run_func (int, int, int (*funct) (int, int));

#endif
